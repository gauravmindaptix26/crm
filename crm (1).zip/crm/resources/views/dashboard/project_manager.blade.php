@extends('layouts.dashboard')

@section('title', 'Manager Dashboard')

@section('content')
    <div class="bg-white p-6 shadow-lg rounded-lg">
        <h1 class="text-2xl font-bold text-secondary">Manager Dashboard</h1>
        <p class="text-gray-600">Track project progress and team performance.</p>
    </div>
    
    <div class="bg-white p-6 shadow-lg rounded-lg">
        <h2 class="text-xl font-semibold">📈 Project Reports</h2>
        <p class="text-gray-500">View key performance metrics.</p>
    </div>

    <div class="bg-white p-6 shadow-lg rounded-lg">
        <h2 class="text-xl font-semibold">🧑‍🤝‍🧑 Team Performance</h2>
        <p class="text-gray-500">Monitor employee productivity and progress.</p>
    </div>
@endsection
