<footer class="bg-gray-200 p-4 text-center text-gray-700">
    &copy; {{ date('Y') }} CRM System | Powered by Laravel
</footer>
