<footer class="bg-gray-200 p-4 text-center text-gray-700">
    &copy; <?php echo e(date('Y')); ?> CRM System | Powered by Laravel
</footer>
<?php /**PATH C:\xampp\htdocs\crm\resources\views/layouts/partials/footer.blade.php ENDPATH**/ ?>