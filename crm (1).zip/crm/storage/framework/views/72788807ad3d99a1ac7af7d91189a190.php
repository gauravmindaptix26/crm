<header class="shadow-md p-4 flex justify-center items-center text-white w-full" 
        style="background: linear-gradient(to right, #0178bc 0%, #00bdda 100%);">
    <h1 class="text-2xl font-semibold flex items-center">
        <i class="fas fa-chart-line text-yellow-300 mr-2"></i>
        Project Management System : <span class="text-yellow-300">Seo Discovery</span>
    </h1>
</header>
<?php /**PATH C:\xampp\htdocs\crm\resources\views/layouts/partials/header.blade.php ENDPATH**/ ?>